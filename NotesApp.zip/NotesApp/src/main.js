import './script/customEl/note-data.js';
import './script/customEl/note-item.js';
import './script/data/dummy-notes.js';
import './script/customEl/note-nav.js';
import './script/customEl/note-foot.js';
import './script/realtimeValidation.js';